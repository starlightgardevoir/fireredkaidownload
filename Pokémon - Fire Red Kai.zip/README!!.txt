!! PATCH THIS ON A CLEAN ROM OF ''Pokemon - FireRed Version (USA, Europe) (Rev 1)'' !!

- In order to patch, open Lunar IPS.exe and click ''Apply Patch''.
Open ''Pokémon - Fire Red Kai.ips'', then ''Pokemon - FireRed Version (USA, Europe) (Rev 1)''.
Save, open with your favourite emulator, and enjoy!

Thank you for playing Pokémon Fire Red Kai!
- Gabrielle and Krys